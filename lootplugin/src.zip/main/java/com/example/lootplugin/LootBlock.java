package com.example.lootplugin;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static org.bukkit.Bukkit.getLogger;

public class LootBlock {

    private final String blockId;
    private final List<LootItem> lootItems;
    private final FileConfiguration config;
    private int progressBarTime;
    private int refreshTime;
    private long lastOpened;
    private String guiName;
    private int guiRows;
    private boolean randomizeItems;
    private final Map<String, Inventory> blockInventories = new HashMap<>(); // 记录每个方块位置的容器

    public LootBlock(String blockId, FileConfiguration mainConfig, boolean globalRandomizeItems) {
        this.blockId = blockId;
        this.lootItems = new ArrayList<>();
        this.config = new YamlConfiguration();
        this.progressBarTime = mainConfig.getInt("loot-blocks." + blockId + ".progress-bar-time", 5);
        this.refreshTime = mainConfig.getInt("loot-blocks." + blockId + ".refresh-time", 300);
        this.randomizeItems = globalRandomizeItems && mainConfig.getBoolean("loot-blocks." + blockId + ".randomize-items", true);
        this.lastOpened = 0;
        this.guiName = mainConfig.getString("loot-blocks." + blockId + ".name", "搜刮方块");
        this.guiRows = mainConfig.getInt("loot-blocks." + blockId + ".rows", 3);
        config.set("blockId", blockId);
    }

    public LootBlock(String blockId, FileConfiguration config, FileConfiguration mainConfig, boolean globalRandomizeItems) {
        this.blockId = blockId;
        this.lootItems = new ArrayList<>();
        this.config = config;
        this.guiName = mainConfig.getString("loot-blocks." + blockId + ".name", "搜刮方块");
        this.guiRows = mainConfig.getInt("loot-blocks." + blockId + ".rows", 3);
        this.progressBarTime = mainConfig.getInt("loot-blocks." + blockId + ".progress-bar-time", 5);
        this.refreshTime = mainConfig.getInt("loot-blocks." + blockId + ".refresh-time", 300);
        this.randomizeItems = globalRandomizeItems && mainConfig.getBoolean("loot-blocks." + blockId + ".randomize-items", true);
        loadConfig();
    }

    private void loadConfig() {
        List<?> items = config.getList("loot-items");
        if (items != null) {
            for (Object itemObj : items) {
                if (itemObj instanceof Map) {
                    Map<String, Object> itemConfig = (Map<String, Object>) itemObj;
                    String materialKey = (String) itemConfig.get("material");
                    Material material = Material.matchMaterial(materialKey);

                    // 检查 Material 是否为 null
                    if (material == null) {
                        getLogger().warning("无效的物品ID: " + materialKey + "，跳过此物品。");
                        continue; // 跳过此物品
                    }

                    int maxAmount = (int) itemConfig.get("amount");
                    double probability = (double) itemConfig.get("probability");
                    lootItems.add(new LootItem(new ItemStack(material, maxAmount), probability / 100.0)); // 概率转换为百分比
                }
            }
        }
        progressBarTime = config.getInt("progress-bar-time", 5);
        refreshTime = config.getInt("refresh-time", 300);
        lastOpened = config.getLong("last-opened", 0);
    }


    public String getBlockId() {
        return blockId;
    }

    public int getProgressBarTime() {
        return progressBarTime;
    }

    public void setProgressBarTime(int progressBarTime) {
        this.progressBarTime = progressBarTime;
        saveConfig();
    }

    public int getRefreshTime() {
        return refreshTime;
    }

    public void setRefreshTime(int refreshTime) {
        this.refreshTime = refreshTime;
        saveConfig();
    }

    public boolean isCooldown() {
        return (System.currentTimeMillis() - lastOpened) < (refreshTime * 1000);
    }

    public void addItem(ItemStack item, int maxAmount, double probability) {
        for (LootItem lootItem : lootItems) {
            if (lootItem.getItemStack().isSimilar(item)) {
                lootItem.getItemStack().setAmount(maxAmount);
                lootItem.setProbability(probability / 100.0); // 概率转换为百分比
                saveConfig();
                return;
            }
        }
        item.setAmount(maxAmount);
        lootItems.add(new LootItem(item, probability / 100.0)); // 概率转换为百分比
        saveConfig();
    }

    public void open(Player player, String blockLocation, boolean refreshItems) {
        Inventory inventory;
        Random random = new Random();

        if (refreshItems || !blockInventories.containsKey(blockLocation)) {
            inventory = Bukkit.createInventory(null, guiRows * 9, guiName);
            for (LootItem lootItem : lootItems) {
                if (random.nextDouble() <= lootItem.getProbability()) {
                    ItemStack item = lootItem.getItemStack().clone();
                    item.setAmount(random.nextInt(lootItem.getItemStack().getAmount()) + 1); // 每次刷新都随机数量
                    inventory.addItem(item);
                }
            }

            if (randomizeItems) {
                List<ItemStack> items = new ArrayList<>();
                for (ItemStack item : inventory.getContents()) {
                    if (item != null) {
                        items.add(item);
                    }
                }
                Collections.shuffle(items);
                inventory.clear();
                for (ItemStack item : items) {
                    int slot;
                    do {
                        slot = random.nextInt(inventory.getSize());
                    } while (inventory.getItem(slot) != null);
                    inventory.setItem(slot, item);
                }
            }

            blockInventories.put(blockLocation, inventory);
            if (refreshItems) {
                lastOpened = System.currentTimeMillis();
                saveConfig();
            }
        } else {
            inventory = blockInventories.get(blockLocation);
        }

        player.openInventory(inventory);
    }

    public FileConfiguration getConfig() {
        YamlConfiguration lootConfig = new YamlConfiguration();
        List<Map<String, Object>> itemsConfig = new ArrayList<>();
        for (LootItem lootItem : lootItems) {
            Map<String, Object> itemConfig = new HashMap<>();
            itemConfig.put("material", lootItem.getItemStack().getType().getKey().toString());
            itemConfig.put("amount", lootItem.getItemStack().getAmount());
            itemConfig.put("probability", lootItem.getProbability() * 100.0); // 概率转换为百分比
            itemsConfig.add(itemConfig);
        }
        lootConfig.set("loot-items", itemsConfig);
        lootConfig.set("progress-bar-time", progressBarTime);
        lootConfig.set("refresh-time", refreshTime);
        lootConfig.set("last-opened", lastOpened);
        lootConfig.set("blockId", blockId);
        lootConfig.set("randomize-items", randomizeItems); // 保存随机摆放选项
        return lootConfig;
    }

    private void saveConfig() {
        File lootBlockFolder = new File("plugins/LootPlugin/lootblocks");
        if (!lootBlockFolder.exists()) {
            lootBlockFolder.mkdirs();
        }

        // 替换不合法的文件名字符
        String fileName = blockId.replaceAll("[^a-zA-Z0-9._-]", "_") + ".yml";
        File lootFile = new File(lootBlockFolder, fileName);
        YamlConfiguration lootConfig = (YamlConfiguration) getConfig();

        try {
            lootConfig.save(lootFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
