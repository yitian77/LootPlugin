package com.example.lootplugin;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class LootPlugin extends JavaPlugin implements Listener {

    private final Map<String, LootBlock> lootBlocks = new HashMap<>();
    private FileConfiguration messages;
    private Sound startSound;
    private Sound endSound;
    private Sound loadingSound;
    private String progressGuiName;
    private int progressGuiRows;
    private boolean globalRandomizeItems; // 全局随机摆放物品选项
    private final Map<String, Long> playerLastOpened = new HashMap<>(); // 用于记录玩家最后打开容器的时间
    private final Map<Player, Boolean> playerProgressCancelled = new HashMap<>(); // 用于记录玩家是否取消了进度条
    private final Map<Player, Boolean> playerSneaking = new HashMap<>(); // 用于记录玩家是否按下Shift键

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadConfig();
        loadMessages();
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        for (LootBlock lootBlock : lootBlocks.values()) {
            saveLootBlockConfig(lootBlock);
        }
    }

    private void loadConfig() {
        FileConfiguration config = getConfig();
        startSound = Sound.valueOf(config.getString("sounds.start", "ENTITY_PLAYER_LEVELUP"));
        endSound = Sound.valueOf(config.getString("sounds.end", "ENTITY_PLAYER_LEVELUP"));
        loadingSound = Sound.valueOf(config.getString("sounds.loading", "BLOCK_ANVIL_LAND"));

        progressGuiName = config.getString("progress-gui.name", "加载中...");
        progressGuiRows = config.getInt("progress-gui.rows", 1);
        globalRandomizeItems = config.getBoolean("global-randomize-items", true); // 从配置文件中读取全局随机摆放物品选项

        File lootBlockFolder = new File(getDataFolder(), "lootblocks");
        if (lootBlockFolder.exists() && lootBlockFolder.isDirectory()) {
            for (File file : Objects.requireNonNull(lootBlockFolder.listFiles())) {
                if (file.isFile() && file.getName().endsWith(".yml")) {
                    YamlConfiguration lootConfig = YamlConfiguration.loadConfiguration(file);
                    String blockId = lootConfig.getString("blockId").toUpperCase();
                    if (blockId != null) {
                        LootBlock lootBlock = new LootBlock(blockId, lootConfig, config, globalRandomizeItems);
                        lootBlocks.put(blockId, lootBlock);
                    }
                }
            }
        }
    }

    private void loadMessages() {
        File messagesFile = new File(getDataFolder(), "messages_zh.yml");
        if (!messagesFile.exists()) {
            saveResource("messages_zh.yml", false);
        }
        messages = YamlConfiguration.loadConfiguration(messagesFile);
    }

    private String getMessage(String key, Object... args) {
        String message = messages.getString("messages." + key, null);
        if (message == null || message.trim().isEmpty()) {
            return null; // 如果语言文件中没有对应内容或内容为空，则返回null
        }
        return MessageFormat.format(message, args);
    }

    @EventHandler
    public void onPlayerSneakToggle(PlayerToggleSneakEvent event) {
        playerSneaking.put(event.getPlayer(), event.isSneaking());
    }

    @EventHandler
    public void onChestOpen(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        Block block = event.getClickedBlock();
        boolean isSneaking = playerSneaking.getOrDefault(player, false);

        // 允许左键和右键行为加载进度条，但按Shift+左键不会触发
        if (block != null && (event.getAction().toString().contains("LEFT_CLICK") || event.getAction().toString().contains("RIGHT_CLICK"))) {
            if (isSneaking && event.getAction().toString().contains("LEFT_CLICK")) {
                return; // 按下Shift键时，左键不会触发
            }

            String blockId = block.getType().getKey().toString().toUpperCase();
            LootBlock lootBlock = lootBlocks.get(blockId);
            if (lootBlock != null) {
                event.setCancelled(true);
                String playerBlockKey = player.getUniqueId() + ":" + block.getLocation().toString();
                long currentTime = System.currentTimeMillis();

                if (lootBlock.isCooldown()) {
                    String message = getMessage("loot_on_cooldown");
                    if (message != null) {
                        player.sendMessage(message);
                    }
                }

                if (!playerLastOpened.containsKey(playerBlockKey) || currentTime - playerLastOpened.get(playerBlockKey) >= lootBlock.getRefreshTime() * 1000) {
                    startProgressBar(player, lootBlock, block.getLocation().toString());
                } else {
                    lootBlock.open(player, block.getLocation().toString(), false); // 不刷新物品
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Player player = (Player) event.getWhoClicked();
        if (event.getView().getTitle().equals(progressGuiName)) {
            // 禁止取出或移动玻璃板
            if (event.getCurrentItem() != null && (event.getCurrentItem().getType() == Material.RED_STAINED_GLASS_PANE || event.getCurrentItem().getType() == Material.GREEN_STAINED_GLASS_PANE)) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        Player player = (Player) event.getPlayer();
        if (event.getView().getTitle().equals(progressGuiName)) {
            playerProgressCancelled.put(player, true); // 记录玩家取消了进度条
        }
    }

    private void startProgressBar(Player player, LootBlock lootBlock, String blockLocation) {
        Inventory progressGui = Bukkit.createInventory(null, progressGuiRows * 9, progressGuiName);
        playerProgressCancelled.put(player, false); // 初始化为未取消

        // 初始化玻璃板为红色
        for (int i = 0; i < progressGui.getSize(); i++) {
            progressGui.setItem(i, new ItemStack(Material.RED_STAINED_GLASS_PANE));
        }

        player.openInventory(progressGui);
        player.playSound(player.getLocation(), startSound, 1.0f, 1.0f);
        player.playSound(player.getLocation(), loadingSound, 1.0f, 1.0f);

        new BukkitRunnable() {
            int time = lootBlock.getProgressBarTime() * 20;
            int slots = progressGui.getSize();
            int colorChangeInterval = time / slots;
            int slot = 0;

            @Override
            public void run() {
                if (playerProgressCancelled.get(player)) { // 检查玩家是否取消了进度条
                    this.cancel();
                    return;
                }

                if (time <= 0) {
                    if (!playerProgressCancelled.get(player)) { // 只有当玩家没有取消进度条时才打开搜刮界面
                        String message = getMessage("loot_opened");
                        if (message != null) {
                            player.sendMessage(message);
                        }
                        player.playSound(player.getLocation(), endSound, 1.0f, 1.0f);
                        player.closeInventory(); // 关闭进度条界面
                        lootBlock.open(player, blockLocation, true); // 刷新物品并打开搜刮界面
                        playerLastOpened.put(player.getUniqueId() + ":" + blockLocation, System.currentTimeMillis());
                    } else {
                        player.closeInventory(); // 如果取消了进度条，也关闭界面
                    }
                    this.cancel();
                } else {
                    if (time % colorChangeInterval == 0 && slot < slots) {
                        progressGui.setItem(slot, new ItemStack(Material.GREEN_STAINED_GLASS_PANE));
                        player.updateInventory(); // 更新玩家的背包
                        slot++;
                    }
                    time--;
                }
            }
        }.runTaskTimer(this, 0, 1);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player) || !sender.isOp()) {
            String message = getMessage("permission_denied");
            if (message != null) {
                sender.sendMessage(message);
            }
            return true;
        }

        Player player = (Player) sender;
        Block block = player.getTargetBlockExact(5); // 获取玩家指向的方块（最大距离5格）

        if (block == null) {
            String message = getMessage("no_block_targeted");
            if (message != null) {
                player.sendMessage(message);
            }
            return true;
        }

        String blockId = block.getType().getKey().toString().toUpperCase();
        LootBlock lootBlock = lootBlocks.get(blockId);

        if (lootBlock == null) {
            String message = getMessage("no_loot_block");
            if (message != null) {
                player.sendMessage(message);
            }
            return true;
        }

        if (command.getName().equalsIgnoreCase("addlootitem")) {
            if (args.length < 2) {
                String message = getMessage("usage_add_loot_item");
                if (message != null) {
                    player.sendMessage(message);
                }
                return true;
            }

            int maxAmount = Integer.parseInt(args[0]);
            double probability = Double.parseDouble(args[1]);

            ItemStack item = player.getInventory().getItemInMainHand().clone();
            lootBlock.addItem(item, maxAmount, probability);
            saveLootBlockConfig(lootBlock);
            String message = getMessage("loot_item_added", blockId, maxAmount, probability);
            if (message != null) {
                player.sendMessage(message);
            }

            return true;
        } else if (command.getName().equalsIgnoreCase("setprogresstime")) {
            if (args.length < 1) {
                String message = getMessage("usage_set_progress_time");
                if (message != null) {
                    player.sendMessage(message);
                }
                return true;
            }

            int time = Integer.parseInt(args[0]);

            lootBlock.setProgressBarTime(time);
            saveLootBlockConfig(lootBlock);
            String message = getMessage("progress_bar_set", time);
            if (message != null) {
                player.sendMessage(message);
            }

            return true;
        } else if (command.getName().equalsIgnoreCase("setrefreshtime")) {
            if (args.length < 1) {
                String message = getMessage("usage_set_refresh_time");
                if (message != null) {
                    player.sendMessage(message);
                }
                return true;
            }

            int time = Integer.parseInt(args[0]);

            lootBlock.setRefreshTime(time);
            saveLootBlockConfig(lootBlock);
            String message = getMessage("refresh_time_set", time);
            if (message != null) {
                player.sendMessage(message);
            }

            return true;
        } else if (command.getName().equalsIgnoreCase("reloadlootplugin")) {
            reloadConfig();
            loadConfig();
            loadMessages();

            // 删除被移除的方块ID对应的配置
            lootBlocks.entrySet().removeIf(entry -> !getConfig().contains("loot-blocks." + entry.getKey()));
            String message = getMessage("plugin_reloaded");
            if (message != null) {
                sender.sendMessage(message);
            }
            return true;
        }

        return false;
    }

    private void saveLootBlockConfig(LootBlock lootBlock) {
        File lootBlockFolder = new File(getDataFolder(), "lootblocks");
        if (!lootBlockFolder.exists()) {
            lootBlockFolder.mkdirs();
        }

        // 替换不合法的文件名字符
        String fileName = lootBlock.getBlockId().replaceAll("[^a-zA-Z0-9._-]", "_") + ".yml";
        File lootFile = new File(lootBlockFolder, fileName);
        YamlConfiguration lootConfig = (YamlConfiguration) lootBlock.getConfig();

        try {
            lootConfig.save(lootFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
