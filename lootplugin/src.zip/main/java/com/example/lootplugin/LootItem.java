package com.example.lootplugin;

import org.bukkit.inventory.ItemStack;

public class LootItem {
    private final ItemStack itemStack;
    private double probability;

    public LootItem(ItemStack itemStack, double probability) {
        this.itemStack = itemStack;
        this.probability = probability;
    }

    public ItemStack getItemStack() {
        return itemStack;
    }

    public double getProbability() {
        return probability;
    }

    public void setProbability(double probability) {
        this.probability = probability;
    }
}
